<?php
define("DB_HOST", "mysql");
define("DB_USERNAME", "datasec_db_2_guest");
define("DB_PASSWORD", "guestpassword");
define("DB_DATABASE_NAME", "datasec_db_2");